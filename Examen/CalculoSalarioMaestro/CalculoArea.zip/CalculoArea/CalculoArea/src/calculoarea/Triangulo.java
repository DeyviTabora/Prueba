/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculoarea;

/**
 *
 * @author Deyvi Tabora
 */
public class Triangulo extends Area {
    
    @Override
    public void Imprimir() {
        System.out.println(area =(largo * ancho)/2);
    }
    
}
