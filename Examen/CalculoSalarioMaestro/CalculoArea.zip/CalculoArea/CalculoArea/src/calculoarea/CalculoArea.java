/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculoarea;
import java.util.Scanner;
/**
 *
 * @author Alumno
 */
public class CalculoArea {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Ingrese el tipo de figura: ");
        String tipo = sc.nextLine();
        
        //Area a = new Area();
        if(tipo.contains("Cuadrado")){
        Cuadrado a = new Cuadrado();
        System.out.println("Ingrese el largo: ");
        double largo = sc.nextDouble();
        a.setLargo(largo);
        a.Imprimir();
        }else if (tipo.contains("Rectangulo")){
        Rectangulo b = new Rectangulo();
        System.out.println("Ingrese el largo: ");
        double largo = sc.nextDouble();
        b.setLargo(largo);
        
        System.out.println("Ingrese el ancho: ");
        double ancho = sc.nextDouble();
        b.setAncho(ancho);
        b.Imprimir();
        }else if(tipo.contains("Triangulo")){
        Triangulo c = new Triangulo();
        System.out.println("Ingrese el largo: ");
        double largo = sc.nextDouble();
        c.setLargo(largo);
        
        System.out.println("Ingrese el ancho: ");
        double ancho = sc.nextDouble();
        c.setAncho(ancho);
        c.Imprimir();
        }
    }
    
}
