/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculoarea;

/**
 *
 * @author Alumno
 */
public class Area extends Calculo {
    protected double ancho;
    protected double largo;
    protected double area;

    public Area() {
    }

    public Area(double ancho, double largo) {
        this.ancho = ancho;
        this.largo = largo;
    }

    public void setAncho(double ancho) {
        this.ancho = ancho;
    }

    public void setLargo(double largo) {
        this.largo = largo;
    }

    public double getAncho() {
        return ancho;
    }

    public double getLargo() {
        return largo;
    }

    @Override
    public void Imprimir() {
        System.out.println(area = largo * ancho);
    }
    
}
